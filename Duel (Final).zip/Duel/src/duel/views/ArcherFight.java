package duel.views;
import duel.common.*;
import duel.common.Character;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Frame;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import java.awt.Font;

public class ArcherFight extends JFrame {

	private JPanel contentPane;
	private JTextField textField2;
	private JButton btnLightattack;
	private JButton btnHeavyattack;
	private JButton btnHome;
	
	static String S = "";
	static Character h1 = new Character("",0,0,0,0);
	static Boss1 Boss1 = new Boss1("HellRaiser",250,12,17,1);
	private JLabel lblHp;
	private JLabel lblhp;
	private JTextField textField;
	private JLabel label;
	
	private JLabel lblCharcerter_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ArcherFight frame = new ArcherFight(h1,Boss1,S);
					frame.setVisible(true);
					frame.setState(Frame.NORMAL);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	
	
	
	}

	/**
	 * Create the frame.
	 */
	public ArcherFight(Character c, Boss1 b1, String S) 
	{
		h1=c;
		Boss1=b1;
		this.S = S;
		
		initComponents();
		createEvents();
		
	
	}



	private void initComponents()
	{
		
		
		setIconImage(Toolkit.getDefaultToolkit().getImage(ArcherFight.class.getResource("/duel/resources/swords.png")));
		setResizable(false);
		setTitle("ArcherFight");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1037, 670);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		//how we changing the images in fight class
		JLabel lblArcher = new JLabel(S);
		lblCharcerter_1 = new JLabel("");
		
		if(S.equals("Archer")) {
			
			lblCharcerter_1.setIcon(new ImageIcon(ArcherFight.class.getResource("/duel/resources/icons8-archer-filled-100.png")));
		}
		else if(S.equals("Shooter")) {
			
			lblCharcerter_1.setIcon(new ImageIcon(ArcherFight.class.getResource("/duel/resources/sinper_100.png")));
		}
		else if(S.equals("Tank")) {
			
			lblCharcerter_1.setIcon(new ImageIcon(ArcherFight.class.getResource("/duel/resources/Tank_100.png")));
		}
		else if(S.equals("Warrior")) {
			
			lblCharcerter_1.setIcon(new ImageIcon(ArcherFight.class.getResource("/duel/resources/Shield_100.png")));
		}
		else if(S.equals("Mage")) {
			
			lblCharcerter_1.setIcon(new ImageIcon(ArcherFight.class.getResource("/duel/resources/Wand_100.png")));
		}
		else if(S.equals("Warlock")) {
			
			lblCharcerter_1.setIcon(new ImageIcon(ArcherFight.class.getResource("/duel/resources/wizard_100.png")));
		}
		else if(S.equals("Rogue")) {
			
			lblCharcerter_1.setIcon(new ImageIcon(ArcherFight.class.getResource("/duel/resources/dagger_100.png")));
		}
		else if(S.equals("Brawler")) {
			
			lblCharcerter_1.setIcon(new ImageIcon(ArcherFight.class.getResource("/duel/resources/Fist_100.png")));
		}
	
		
		btnLightattack = new JButton("LightAttack");
	
		
		btnHeavyattack = new JButton("HeavyAttack");
		
		
		lblHp = new JLabel("HP:" + h1.getHp());
		lblHp.setFont(new Font("Tahoma", Font.BOLD, 30));
		
		JLabel lblBoss = new JLabel("Boss");
		
		textField2 = new JTextField();
		textField2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField2.setBorder(null);
		textField2.setBackground(UIManager.getColor("Button.background"));
		textField2.setColumns(10);
		
		lblhp = new JLabel(Boss1.getHp() + ":HP");
		lblhp.setFont(new Font("Tahoma", Font.BOLD, 30));
		
		btnHome = new JButton("");
		
		btnHome.setIcon(new ImageIcon(ArcherFight.class.getResource("/duel/resources/home.png")));
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField.setBorder(null);
		textField.setBackground(UIManager.getColor("Button.background"));
		textField.setColumns(10);
		
		label = new JLabel("");
		label.setIcon(new ImageIcon(ArcherFight.class.getResource("/duel/resources/hannya_Bigger.png")));
		
		
		
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap(802, Short.MAX_VALUE)
					.addComponent(lblBoss)
					.addGap(186))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(32)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblHp)
							.addPreferredGap(ComponentPlacement.RELATED, 903, Short.MAX_VALUE)
							.addComponent(lblhp))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
									.addComponent(textField2)
									.addGroup(gl_contentPane.createSequentialGroup()
										.addComponent(lblArcher)
										.addGap(61)
										.addComponent(btnLightattack)
										.addGap(48)
										.addComponent(btnHeavyattack)))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(165)
									.addComponent(lblCharcerter_1)))
							.addPreferredGap(ComponentPlacement.RELATED, 155, Short.MAX_VALUE)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, 396, GroupLayout.PREFERRED_SIZE)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(label)
									.addGap(70)))))
					.addContainerGap())
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(btnHome)
					.addContainerGap(963, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(btnHome)
					.addGap(7)
					.addComponent(lblBoss)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(104)
							.addComponent(lblCharcerter_1)
							.addPreferredGap(ComponentPlacement.RELATED, 170, Short.MAX_VALUE)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
									.addComponent(btnLightattack)
									.addComponent(btnHeavyattack))
								.addComponent(lblArcher))
							.addGap(45)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblHp)
								.addComponent(lblhp)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(53)
							.addComponent(label)))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(textField2, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE))
					.addGap(22))
		);
		contentPane.setLayout(gl_contentPane);
		
	}
	
	
	private void createEvents()
	{
		btnHome.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				setVisible(false);
				CharacterSelect A = new CharacterSelect();
				A.setVisible(true);///takes you back to character select frame
			}
		});
		
		btnLightattack.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				//light attack sequence
				h1.Att1(Boss1);
				Boss1.Att1(h1);
				
				h1.setLightAtt(h1.getLightAtt()+2 );
				Boss1.setHeavyAtt(Boss1.getHeavyAtt()-2);
				 if (h1.getHp()<=0) {
					 
					JOptionPane.showMessageDialog(null, "You Have Beeen Defeated!");
					setVisible(false);
					CharacterSelect A = new CharacterSelect();
					A.setVisible(true);
				}	
				else if (Boss1.getHp()<=0) {
					
					JOptionPane.showMessageDialog(null, "You Have Won!");
					setVisible(false);
					CharacterSelect B = new CharacterSelect();
					B.setVisible(true);
				
				}
				 lblHp.setText("Hp:" + h1.getHp());
					lblhp.setText(Boss1.getHp() +":Hp");
					textField.setText("You inflicted " + h1.getLightAtt() + " on the boss!");
					textField2.setText("The Boss Inflicted " + Boss1.getLightAtt() + " back on to you!");
					
					
			}
		});
		
		btnHeavyattack.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				//heavy attack sequence
				if (h1.getHp()>0 && Boss1.getHp()>0) {
					h1.Att2(Boss1);
					Boss1.Att1(h1);
					
					h1.setHeavyAtt(h1.getHeavyAtt()+2 );
					Boss1.setLightAtt(Boss1.getLightAtt()-2);
					
					lblHp.setText("Hp:" + h1.getHp());
					lblhp.setText(Boss1.getHp() +":Hp");
					textField.setText("You inflicted " + h1.getHeavyAtt() + " on the boss!");
					textField2.setText("The Boss Inflicted " + Boss1.getHeavyAtt() + " back on to you!");
					}
					else if (h1.getHp()<=0) {
						JOptionPane.showMessageDialog(null, "You Have Beeen Defeated!");
						setVisible(false);
						CharacterSelect A = new CharacterSelect();
						A.setVisible(true);
					}	
					else if (Boss1.getHp()<=0) {
						JOptionPane.showMessageDialog(null, "You Have Won!");
						setVisible(false);
						CharacterSelect B = new CharacterSelect();
						B.setVisible(true);
					
					}
			}
		});
		
		
	}
}
