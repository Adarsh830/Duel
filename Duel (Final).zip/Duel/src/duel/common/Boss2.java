package duel.common;

public class Boss2 extends Character {
protected int classPerk; // upp all abilities *2

	
	public Boss2(String name, int hp, int lightAtt, int heavyAtt,int classPerk) {
		super(name,hp,lightAtt,heavyAtt,classPerk);
		super.heavyAtt = heavyAtt+classPerk;	
		super.lightAtt = lightAtt+classPerk;
		super.hp = hp+classPerk;
	
	}
	
	public int getClassPerk() {
		System.out.println("Boost ALL Attcks Even More!");
		return classPerk;
	}
	public void setClassPerk(int BoostAll2) {
		this.classPerk = BoostAll2;
	}
	
	
	

}


