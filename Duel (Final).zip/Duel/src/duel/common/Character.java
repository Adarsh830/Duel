package duel.common;

import java.util.Comparator;

public class Character {
		protected String name; //class name
		protected int hp; // health points
		protected int lightAtt;  //does attack damage
		protected int heavyAtt;  // does attack damage
		protected int ultimate;
		protected int classPerk;
	

		public Character (String name, int hp, int lightAtt, int heavyAtt, int classPerk) {
			this.name = name;
			this.hp=hp;
			this.lightAtt = lightAtt;
			this.heavyAtt = heavyAtt;
			this.classPerk = classPerk;
			
			
		}
		public Character() {
			this.name="";
			this.hp=0;
			this.lightAtt=0;
			this.heavyAtt=0;
			this.classPerk=0;
		}
		
		
		//getters and setters
		
		public String getName() {
			return name;
		}
	
		public void setName(String name) {
			this.name = name;
		}
		
		public int getHp() {
			return hp;
		}
	
		public void setHp(int hp) {
			this.hp = hp;
		}
		public int getLightAtt() {
			return lightAtt;
		}
		
		public void setLightAtt(int lightAtt) {
			this.lightAtt = lightAtt;
		}
		
		public int getHeavyAtt() {
			return heavyAtt;
		}
		public void setHeavyAtt(int heavyAtt) {
			this.heavyAtt = heavyAtt;
		}
		
		
		

		
		public void Att1(Character c) {
			c.setHp(c.getHp()-this.lightAtt);
			
		}
		public void Att2(Character c) {
			c.setHp(c.getHp()-this.heavyAtt);
		}
		
		
		public String toString() {
			return "Name = "+this.name+"  \t Hp = "+this.hp+"  \t lightAtt = "+this.lightAtt+"  \t HeavyAtt = "+this.heavyAtt;
		}
		
		Comparator<Character> HpOrder =  new Comparator<Character>() {
	        public int compare(Character c1, Character c2) {
	            return c1.getHp()-c2.getHp();
	        }
	    };
	    
		
	
}
