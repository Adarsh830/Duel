package duel.common;

public class Mage extends Character {
	protected int classPerk; //boosts heavy

	
	public Mage(String name, int hp, int lightAtt, int heavyAtt,int classPerk) {
		super(name,hp,lightAtt,heavyAtt,classPerk);

		super.heavyAtt = heavyAtt+classPerk;	
	
	}
	
	public int getClassPerk() {
		System.out.println("Heavy Attack Boost");
		return classPerk;
	}
	public void setClassPerk(int heavyAttBoost) {
		this.classPerk = heavyAttBoost;
	}
	
	
	

}
