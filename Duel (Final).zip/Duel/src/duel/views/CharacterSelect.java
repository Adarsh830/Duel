package duel.views;
import duel.common.*;
import duel.common.Character;
import duel.views.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JRadioButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.ButtonGroup;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Component;
import javax.swing.JLabel;

public class CharacterSelect extends JFrame {

	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JButton btnReady;
	private JButton btnInfo;
	private JRadioButton rdbtnArcher;
	private JRadioButton rdbtnMage;
	private JRadioButton rdbtnShooter;
	private JRadioButton rdbtnWarlock;
	private JRadioButton rdbtnRouge;
	private JRadioButton rdbtnTank;
	private JRadioButton rdbtnBrawler;
	private JRadioButton rdbtnWarrior;
	
	Tank t1 = new Tank("Tank",100,10,14,20);
	Tank t2 = new Tank("Warrior",100,12,13,40);
	Hunter h1 = new Hunter("Archer",90,10,11,10);
	Hunter h2 = new Hunter("Shooter",100,4,20,7);
	Mage m1 = new Mage("Mage",90,5,20,5);
	Mage m2 = new Mage("Warlock",85,5,15,10);
	Brawler b1 = new Brawler("Brawler",100,7,17,3);
	Brawler b2 = new Brawler("Rogue",105,6,12,5);
	Boss1 Boss1 = new Boss1("Hell Raiser",200,12,17,1);
	Boss2 Boss2 = new Boss2("Final EXAM",200,12,17,1);
	
Character[] C = new Character[10];{
		
		C[0] = t1;
		C[1] = t2;
		C[2] = h1;
		C[3] = h2;
		C[4] = m1;
		C[5] = m2;
		C[6] = b1;
		C[7] = b2;
		C[8] = Boss1;
		C[9] = Boss2;
		
	}
	
	
	
	private JLabel label;
	private JLabel label_1;
	private JLabel label_2;
	private JLabel label_3;
	private JLabel label_4;
	private JLabel label_5;
	private JLabel label_6;
	private JLabel label_7;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				try
				{
					CharacterSelect frame = new CharacterSelect();
					frame.setVisible(true);
				} 
				
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CharacterSelect() 
	{
		

		
		initComponents();
		createEvents();
		
	
	}
	
	
	///////////////////////////////////////////////////////////////////////////////
	///this method contains all of the code for creating components////////////////
	//////////////////////////////////////////////////////////////////////////////

	private void initComponents() 
	{
		setTitle("Duel");
		setResizable(false);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1037, 670);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		rdbtnArcher = new JRadioButton("Archer");
		rdbtnArcher.setSelected(true);
		buttonGroup.add(rdbtnArcher);
		rdbtnArcher.setFont(new Font("Georgia", Font.BOLD, 16));
		
		rdbtnShooter = new JRadioButton("Shooter");
		buttonGroup.add(rdbtnShooter);
		rdbtnShooter.setFont(new Font("Georgia", Font.BOLD, 16));
		
		rdbtnTank = new JRadioButton("Tank");
		buttonGroup.add(rdbtnTank);
		rdbtnTank.setFont(new Font("Georgia", Font.BOLD, 16));
		
		rdbtnWarrior = new JRadioButton("Warrior");
		buttonGroup.add(rdbtnWarrior);
		rdbtnWarrior.setFont(new Font("Georgia", Font.BOLD, 16));
		
		rdbtnMage = new JRadioButton("Mage");
		buttonGroup.add(rdbtnMage);
		rdbtnMage.setFont(new Font("Georgia", Font.BOLD, 16));
		
		rdbtnWarlock = new JRadioButton("Warlock");
		buttonGroup.add(rdbtnWarlock);
		rdbtnWarlock.setFont(new Font("Georgia", Font.BOLD, 16));
		
		rdbtnRouge = new JRadioButton("Rogue");
		buttonGroup.add(rdbtnRouge);
		rdbtnRouge.setFont(new Font("Georgia", Font.BOLD, 16));
		
		rdbtnBrawler = new JRadioButton("Brawler");
		buttonGroup.add(rdbtnBrawler);
		rdbtnBrawler.setFont(new Font("Georgia", Font.BOLD, 16));
		
		btnReady = new JButton("READY!");
		btnInfo = new JButton("");
		
		btnInfo.setIcon(new ImageIcon(CharacterSelect.class.getResource("/duel/resources/info.png")));
		setIconImage(Toolkit.getDefaultToolkit().getImage(CharacterSelect.class.getResource("/duel/resources/swords.png")));
		
		label = new JLabel("");
		label.setIcon(new ImageIcon(CharacterSelect.class.getResource("/duel/resources/Bow_50.png")));
		
		label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(CharacterSelect.class.getResource("/duel/resources/Gun_50.png")));
		
		label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(CharacterSelect.class.getResource("/duel/resources/Tank_50.png")));
		
		label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon(CharacterSelect.class.getResource("/duel/resources/Shield_50.png")));
		
		label_4 = new JLabel("");
		label_4.setIcon(new ImageIcon(CharacterSelect.class.getResource("/duel/resources/Wand_50.png")));
		
		label_5 = new JLabel("");
		label_5.setIcon(new ImageIcon(CharacterSelect.class.getResource("/duel/resources/wizard_50.png")));
		
		label_6 = new JLabel("");
		label_6.setIcon(new ImageIcon(CharacterSelect.class.getResource("/duel/resources/dagger_50.png")));
		
		label_7 = new JLabel("");
		label_7.setIcon(new ImageIcon(CharacterSelect.class.getResource("/duel/resources/Fist_50.png")));
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(75)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(rdbtnArcher)
								.addComponent(rdbtnMage))
							.addGap(132)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(rdbtnShooter)
								.addComponent(rdbtnWarlock))
							.addGap(201)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(rdbtnRouge)
								.addComponent(rdbtnTank))
							.addGap(135)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(rdbtnBrawler)
								.addComponent(rdbtnWarrior)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(455)
									.addComponent(btnReady)
									.addPreferredGap(ComponentPlacement.RELATED, 406, Short.MAX_VALUE))
								.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
									.addContainerGap()
									.addComponent(label_3)
									.addGap(57)))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnInfo)))
					.addContainerGap())
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(97)
					.addComponent(label)
					.addGap(177)
					.addComponent(label_1)
					.addGap(238)
					.addComponent(label_2)
					.addContainerGap(358, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(89)
					.addComponent(label_4)
					.addGap(175)
					.addComponent(label_5)
					.addGap(252)
					.addComponent(label_6)
					.addPreferredGap(ComponentPlacement.RELATED, 173, Short.MAX_VALUE)
					.addComponent(label_7)
					.addGap(131))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap(83, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(label_1)
								.addComponent(label))
							.addGap(59))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(label_3)
								.addComponent(label_2))
							.addGap(50)))
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(rdbtnArcher)
						.addComponent(rdbtnShooter)
						.addComponent(rdbtnWarrior)
						.addComponent(rdbtnTank))
					.addGap(115)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(label_4)
						.addComponent(label_5)
						.addComponent(label_6)
						.addComponent(label_7))
					.addGap(49)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(rdbtnMage)
						.addComponent(rdbtnWarlock)
						.addComponent(rdbtnBrawler)
						.addComponent(rdbtnRouge))
					.addGap(80)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnInfo)
						.addComponent(btnReady))
					.addGap(41))
		);
		contentPane.setLayout(gl_contentPane);
	}
	
	///////////////////////////////////////////////////////////////////////////////
	///this method contains all of the code for creating events////////////////
	//////////////////////////////////////////////////////////////////////////////
	
	private void createEvents() 
	{
		btnReady.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0)
			{
				if (rdbtnArcher.isSelected()) {
					//change to fight frame for Archer
					setVisible(false);
					ArcherFight A = new ArcherFight( h1,Boss1,"Archer");
					A.setVisible(true);
				}	
				else if (rdbtnShooter.isSelected()) {
					//change to fight frame for Shooter
					setVisible(false);
					ArcherFight B = new ArcherFight(h2,Boss1,"Shooter");
					B.setVisible(true);
				}
				else if (rdbtnTank.isSelected()) {
								//change to fight frame for Tank
					setVisible(false);
					ArcherFight C = new ArcherFight( t1,Boss1,"Tank");
					C.setVisible(true);
				}
				else if (rdbtnWarrior.isSelected()) {
					//change to fight frame for Warrior
					setVisible(false);
					ArcherFight D = new ArcherFight( t2,Boss1,"Warrior");
					D.setVisible(true);
					
				}
				else if (rdbtnMage.isSelected()) {
					//change to fight frame for Mage
					setVisible(false);
					ArcherFight E = new ArcherFight( m1,Boss1,"Mage");
					E.setVisible(true);
				}
				else if (rdbtnWarlock.isSelected()) {
					//change to fight frame for Warlock
					setVisible(false);
					ArcherFight F = new ArcherFight( m2,Boss1,"Warlock");
					F.setVisible(true);
				}
				else if (rdbtnRouge.isSelected()) {
					//change to fight frame for Rouge
					setVisible(false);
					ArcherFight G = new ArcherFight( b1,Boss1,"Rogue");
					G.setVisible(true);
				}
				else if(rdbtnBrawler.isSelected()) {
					//change to fight frame for Brawler
					setVisible(false);
					ArcherFight H = new ArcherFight( b2,Boss1,"Rouge");
					H.setVisible(true);
				}
			
			}
		});
		
		btnInfo.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				setVisible(false);
				InfoPage A = new InfoPage();
				A.setVisible(true);///takes you back to character select frame
			}
		});
		
	}
}
