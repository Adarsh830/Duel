package duel.views;
import duel.common.*;
import duel.common.Character;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.Toolkit;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
import java.awt.Font;

public class InfoPage extends JFrame {

	private JPanel contentPane;
	private JTextField txtSortCharacters;
	private JTextArea textField;
	private JButton button;
	
		
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InfoPage frame = new InfoPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InfoPage() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(InfoPage.class.getResource("/duel/resources/swords.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1037, 670);
		contentPane = new JPanel();
		contentPane.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		txtSortCharacters = new JTextField();
		txtSortCharacters.setBorder(null);
		txtSortCharacters.setBackground(UIManager.getColor("Button.background"));
		txtSortCharacters.setText("Please Select a Sort Type");
		txtSortCharacters.setColumns(10);
		
		ArrayList<Character> C = new ArrayList<Character>();{
			
			Tank t1 = new Tank("Tank   ",100,10,15,20);
			Tank t2 = new Tank("Warrior",100,9,13,40);
			Hunter h1 = new Hunter("Archer",90,6,11,10);
			Hunter h2 = new Hunter("Shooter",100,4,20,7);
			Mage m1 = new Mage("Mage   ",90,5,20,5);
			Mage m2 = new Mage("Warlock",85,5,15,10);
			Brawler b1 = new Brawler("Brawler",100,7,17,3);
			Brawler b2 = new Brawler("Rogue  ",105,6,12,5);
			Boss1 Boss1 = new Boss1("Hell Raiser",200,15,20,1);
			Boss2 Boss2 = new Boss2("Final EXAM",200,15,25,1);
			C.add(t1);
			C.add(t2);
			C.add(h1);
			C.add(h2);
			C.add(m1);
			C.add(m2);
			C.add(b1);
			C.add(b2);
			C.add(Boss1);
			C.add(Boss2);
			
		}
		
		String[] SortType = { "Name", "HP","LightAtt", "HeavyAtt"};
		
		JComboBox comboBox = new JComboBox(SortType);
		comboBox.setFont(new Font("Times New Roman", Font.BOLD, 20));
		
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JComboBox cb = (JComboBox)e.getSource();
				 String ST = (String)cb.getSelectedItem();
				 if(ST.equals("Name")) {
					 textField.setText("");
					 Comparator<Character> NameOrder =  new Comparator<Character>() {
					        public int compare(Character c1, Character c2) {
					            return c1.getName().compareTo(c2.getName());
					        }
					    };
					 Collections.sort(C,NameOrder);
					 Iterator<Character> itr = C.iterator();
					 while(itr.hasNext()) {
						 textField.append(itr.next().toString()+"\n");;					 
						 }
					 
					 
				 }
				 else if(ST.equals("HP")) {
					 textField.setText("");
					 Comparator<Character> HpOrder =  new Comparator<Character>() {
					        public int compare(Character c1, Character c2) {
					            return c2.getHp()-c1.getHp();
					        }
					    };
					 Collections.sort(C,HpOrder);
					 Iterator<Character> itr = C.iterator();
					 while(itr.hasNext()) {
						 textField.append(itr.next().toString()+"\n");;					 
						 }
					 
					 
				 }
				 else if(ST.equals("LightAtt")) {
					 textField.setText("");
					 Comparator<Character> LightAttOrder =  new Comparator<Character>() {
					        public int compare(Character c1, Character c2) {
					            return c2.getLightAtt()-c1.getLightAtt();
					        }
					    };
					 Collections.sort(C,LightAttOrder);
					 Iterator<Character> itr = C.iterator();
					 while(itr.hasNext()) {
						 textField.append(itr.next().toString()+"\n");;					 
						 }
					 
					 
				 }
				 else if(ST.equals("HeavyAtt")) {
					 textField.setText("");
					 Comparator<Character> HeavyAttOrder =  new Comparator<Character>() {
					        public int compare(Character c1, Character c2) {
					            return c2.getHeavyAtt()-c1.getHeavyAtt();
					        }
					    };
					 Collections.sort(C,HeavyAttOrder);
					 Iterator<Character> itr = C.iterator();
					 while(itr.hasNext()) {
						 textField.append(itr.next().toString()+"\n");;					 
						 }
					 
					 
				 }
				 
				
				
			}
		});
		
		JLabel lblSelectSortType = new JLabel("Select Sort Type");
		lblSelectSortType.setFont(new Font("Tahoma", Font.ITALIC, 15));
		
		textField = new JTextArea();
		textField.setFont(new Font("Georgia", Font.PLAIN, 20));
		textField.setBackground(UIManager.getColor("Button.background"));
		textField.setColumns(10);
		
		button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				CharacterSelect A = new CharacterSelect();
				A.setVisible(true);///takes you back to character select frame
			}
		});
		
		button.setIcon(new ImageIcon(InfoPage.class.getResource("/duel/resources/home.png")));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(button))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(56)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, 224, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblSelectSortType, GroupLayout.PREFERRED_SIZE, 131, GroupLayout.PREFERRED_SIZE)
								.addComponent(txtSortCharacters, GroupLayout.PREFERRED_SIZE, 874, GroupLayout.PREFERRED_SIZE)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(78)
							.addComponent(textField, GroupLayout.PREFERRED_SIZE, 840, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(75, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(17)
					.addComponent(button)
					.addGap(18)
					.addComponent(txtSortCharacters, GroupLayout.PREFERRED_SIZE, 66, GroupLayout.PREFERRED_SIZE)
					.addGap(7)
					.addComponent(lblSelectSortType)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(30)
					.addComponent(textField, GroupLayout.PREFERRED_SIZE, 305, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(74, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
