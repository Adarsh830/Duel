package duel.common;

public class Tank extends Character {
	protected int classPerk; // boosts hp

	
	public Tank (String name, int hp, int lightAtt, int heavyAtt,int classPerk) {
		super(name,hp,lightAtt,heavyAtt,classPerk);

		super.hp=hp+classPerk;
		
	
	}

	public int getClassPerk() {
		System.out.println("HP Boost");
		return classPerk;
	}
	public void setClassPerk(int hpBoost) {
		this.classPerk = hpBoost;
	}
	
	
	

}
