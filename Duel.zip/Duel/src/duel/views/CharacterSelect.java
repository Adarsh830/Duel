package duel.views;
import duel.common.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JRadioButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.ButtonGroup;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CharacterSelect extends JFrame {

	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JButton btnReady;
	private JButton btnInfo;
	private JRadioButton rdbtnArcher;
	private JRadioButton rdbtnMage;
	private JRadioButton rdbtnShooter;
	private JRadioButton rdbtnWarlock;
	private JRadioButton rdbtnRouge;
	private JRadioButton rdbtnTank;
	private JRadioButton rdbtnBrawler;
	private JRadioButton rdbtnWarrior;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				try
				{
					CharacterSelect frame = new CharacterSelect();
					frame.setVisible(true);
				} 
				
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CharacterSelect() 
	{
		
		setTitle("Duel");
		setResizable(false);
		
		initComponents();
		createEvents();
		
	
	}
	
	
	///////////////////////////////////////////////////////////////////////////////
	///this method contains all of the code for creating components////////////////
	//////////////////////////////////////////////////////////////////////////////

	private void initComponents() 
	{
		setTitle("Duel");
		setResizable(false);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1033, 666);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		rdbtnArcher = new JRadioButton("Archer");
		rdbtnArcher.setSelected(true);
		buttonGroup.add(rdbtnArcher);
		rdbtnArcher.setFont(new Font("Georgia", Font.BOLD, 16));
		
		rdbtnShooter = new JRadioButton("Shooter");
		buttonGroup.add(rdbtnShooter);
		rdbtnShooter.setFont(new Font("Georgia", Font.BOLD, 16));
		
		rdbtnTank = new JRadioButton("Tank");
		buttonGroup.add(rdbtnTank);
		rdbtnTank.setFont(new Font("Georgia", Font.BOLD, 16));
		
		rdbtnWarrior = new JRadioButton("Warrior");
		buttonGroup.add(rdbtnWarrior);
		rdbtnWarrior.setFont(new Font("Georgia", Font.BOLD, 16));
		
		rdbtnMage = new JRadioButton("Mage");
		buttonGroup.add(rdbtnMage);
		rdbtnMage.setFont(new Font("Georgia", Font.BOLD, 16));
		
		rdbtnWarlock = new JRadioButton("Warlock");
		buttonGroup.add(rdbtnWarlock);
		rdbtnWarlock.setFont(new Font("Georgia", Font.BOLD, 16));
		
		rdbtnRouge = new JRadioButton("Rouge");
		buttonGroup.add(rdbtnRouge);
		rdbtnRouge.setFont(new Font("Georgia", Font.BOLD, 16));
		
		rdbtnBrawler = new JRadioButton("Brawler");
		buttonGroup.add(rdbtnBrawler);
		rdbtnBrawler.setFont(new Font("Georgia", Font.BOLD, 16));
		
		btnReady = new JButton("READY!");
		btnInfo = new JButton("");
		
		btnInfo.setIcon(new ImageIcon(CharacterSelect.class.getResource("/duel/resources/info.png")));
		setIconImage(Toolkit.getDefaultToolkit().getImage(CharacterSelect.class.getResource("/duel/resources/swords.png")));
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(75)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(rdbtnArcher)
								.addComponent(rdbtnMage))
							.addGap(132)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(rdbtnShooter)
								.addComponent(rdbtnWarlock))
							.addGap(201)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(rdbtnRouge)
								.addComponent(rdbtnTank))
							.addGap(135)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(rdbtnBrawler)
								.addComponent(rdbtnWarrior)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(455)
							.addComponent(btnReady)
							.addPreferredGap(ComponentPlacement.RELATED, 403, Short.MAX_VALUE)
							.addComponent(btnInfo)))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(178)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(rdbtnArcher)
						.addComponent(rdbtnShooter)
						.addComponent(rdbtnWarrior)
						.addComponent(rdbtnTank))
					.addPreferredGap(ComponentPlacement.RELATED, 226, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(rdbtnMage)
						.addComponent(rdbtnWarlock)
						.addComponent(rdbtnBrawler)
						.addComponent(rdbtnRouge))
					.addGap(80)
					.addComponent(btnReady)
					.addGap(45))
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap(567, Short.MAX_VALUE)
					.addComponent(btnInfo)
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
	}
	
	///////////////////////////////////////////////////////////////////////////////
	///this method contains all of the code for creating events////////////////
	//////////////////////////////////////////////////////////////////////////////
	
	private void createEvents() 
	{
		btnReady.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0)
			{
				if (rdbtnArcher.isSelected())
					JOptionPane.showMessageDialog(btnReady,"archer");//change to fight frame for Archer
				if (rdbtnShooter.isSelected())
					JOptionPane.showMessageDialog(btnReady, "Shooter");//change to fight frame for Shooter
				if (rdbtnTank.isSelected())
					JOptionPane.showMessageDialog(btnReady, "Tank");//change to fight frame for Tank
				if (rdbtnWarrior.isSelected())
					JOptionPane.showMessageDialog(btnReady, "Warrior");//change to fight frame for Warrior
				if (rdbtnMage.isSelected())
					JOptionPane.showMessageDialog(btnReady, "Mage");//change to fight frame for Mage
				if (rdbtnWarlock.isSelected())
					JOptionPane.showMessageDialog(btnReady, "Warlock");//change to fight frame for Warlock
				if (rdbtnRouge.isSelected())
					JOptionPane.showMessageDialog(btnReady, "Rouge");//change to fight frame for Rouge
				if (rdbtnBrawler.isSelected())
					JOptionPane.showMessageDialog(btnReady, "Brawler");//change to fight frame for Brawler
				
			
			}
		});
		
		btnInfo.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				//need to take me to information page that shows how the game works and sot by (name,hp,lighatt,heavyatt)
			}
		});
	}
}
