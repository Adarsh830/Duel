package duel.common;
public class Boss1 extends Character {
	protected int classPerk; // booosts all

	
	public Boss1(String name, int hp, int lightAtt, int heavyAtt,int classPerk) {
		super(name,hp,lightAtt,heavyAtt);
		this.classPerk = classPerk;
		super.heavyAtt = heavyAtt+classPerk;	
		super.lightAtt = lightAtt+classPerk;
		super.hp = hp+classPerk;
	
	}
	
	public int getClassPerk() {
		System.out.println("Boost ALL STATS!");
		return classPerk;
	}
	public void setClassPerk(int allBoost) {
		this.classPerk = allBoost;
	}
	
	
	

}