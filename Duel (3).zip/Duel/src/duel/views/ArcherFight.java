package duel.views;
import duel.common.*;


import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Frame;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ArcherFight extends JFrame {

	private JPanel contentPane;
	private JTextField textField2;
	private JButton btnLightattack;
	private JButton btnHeavyattack;
	private JButton btnHome;
	
	
	Tank t1 = new Tank("Tank",100,10,15,10);
	Tank t2 = new Tank("Warrior",100,10,15,10);
	static Hunter h1 = new Hunter("Archer",100,10,15,3);
	Hunter h2 = new Hunter("Shooter",100,10,15,5);
	Mage m1 = new Mage("Mage",100,10,15,5);
	Mage m2 = new Mage("Warlock",100,10,15,5);
	Brawler b1 = new Brawler("Brawler",100,10,15,5);
	Brawler b2 = new Brawler("Rouge",100,10,15,5);
	static Boss1 Boss1 = new Boss1("Hell Raiser",200,12,17,1);
	Boss2 Boss2 = new Boss2("Final EXAM",200,12,17,1);
	private JLabel lblHp;
	private JLabel lblhp;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ArcherFight frame = new ArcherFight();
					frame.setVisible(true);
					frame.setState(Frame.NORMAL);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	
	
	
	}

	/**
	 * Create the frame.
	 */
	public ArcherFight() 
	{
		
		initComponents();
		createEvents();
		
	
	}



	private void initComponents()
	{
		
		
		setIconImage(Toolkit.getDefaultToolkit().getImage(ArcherFight.class.getResource("/duel/resources/swords.png")));
		setResizable(false);
		setTitle("ArcherFight");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1036, 669);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblArcher = new JLabel("Archer");
		
		btnLightattack = new JButton("LightAttack");
	
		
		btnHeavyattack = new JButton("HeavyAttack");
		
		
		lblHp = new JLabel("HP:" + h1.getHp());
		
		JLabel lblBoss = new JLabel("Boss");
		
		textField2 = new JTextField();
		textField2.setColumns(10);
		
		lblhp = new JLabel(Boss1.getHp() + ":HP");
		
		btnHome = new JButton("");
		
		btnHome.setIcon(new ImageIcon(ArcherFight.class.getResource("/duel/resources/home.png")));
		
		textField = new JTextField();
		textField.setColumns(10);
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap(802, Short.MAX_VALUE)
					.addComponent(lblBoss)
					.addGap(186))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(32)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblHp)
							.addPreferredGap(ComponentPlacement.RELATED, 867, Short.MAX_VALUE)
							.addComponent(lblhp))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
								.addComponent(textField2, Alignment.LEADING)
								.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
									.addComponent(lblArcher)
									.addGap(61)
									.addComponent(btnLightattack)
									.addGap(48)
									.addComponent(btnHeavyattack)))
							.addPreferredGap(ComponentPlacement.RELATED, 191, Short.MAX_VALUE)
							.addComponent(textField, GroupLayout.PREFERRED_SIZE, 396, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap())
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(btnHome)
					.addContainerGap(963, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(btnHome)
					.addGap(7)
					.addComponent(lblBoss)
					.addPreferredGap(ComponentPlacement.RELATED, 294, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(btnLightattack)
							.addComponent(btnHeavyattack))
						.addComponent(lblArcher))
					.addGap(45)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblHp)
						.addComponent(lblhp))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(textField2, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE))
					.addGap(22))
		);
		contentPane.setLayout(gl_contentPane);
		
	}
	
	
	private void createEvents()
	{
		btnHome.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				setVisible(false);
				CharacterSelect A = new CharacterSelect();
				A.setVisible(true);///takes you back to character select frame
			}
		});
		
		btnLightattack.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if (h1.getHp()>0 && Boss1.getHp()>0) {
				h1.Att1(Boss1);
				lblhp.setText(Boss1.getHp() +":Hp");
				textField.setText("You inflicted " + h1.getLightAtt() + " on the boss!");
				textField2.setText("The Boss Inflicted " + Boss1.getLightAtt() + " back on to you!");
				}
				else if (h1.getHp()<=0) {
					JOptionPane.showMessageDialog(null, "You Have Beeen Defeated!");
					setVisible(false);
					CharacterSelect A = new CharacterSelect();
					A.setVisible(true);
				}	
				else if (Boss1.getHp()<=0) {
					JOptionPane.showMessageDialog(null, "You Have Won!");
					setVisible(false);
					CharacterSelect B = new CharacterSelect();
					B.setVisible(true);
				//does light attack
				}
			}
		});
		
		btnHeavyattack.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if (h1.getHp()>0 && Boss1.getHp()>0) {
					h1.Att2(Boss1);
					lblhp.setText(Boss1.getHp() +":Hp");
					textField.setText("You inflicted " + h1.getHeavyAtt() + " on the boss!");
					textField2.setText("The Boss Inflicted " + Boss1.getHeavyAtt() + " back on to you!");
					}
					else if (h1.getHp()<=0) {
						JOptionPane.showMessageDialog(null, "You Have Beeen Defeated!");
						setVisible(false);
						CharacterSelect A = new CharacterSelect();
						A.setVisible(true);
					}	
					else if (Boss1.getHp()<=0) {
						JOptionPane.showMessageDialog(null, "You Have Won!");
						setVisible(false);
						CharacterSelect B = new CharacterSelect();
						B.setVisible(true);
					//does light attack
					}
			}
		});
		
		
	}
}
