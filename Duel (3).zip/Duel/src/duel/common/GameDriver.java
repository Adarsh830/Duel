package duel.common;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class GameDriver {
	 
	public static void main(String[] args) {
		 
		Tank t1 = new Tank("Tank",100,10,15,10);
		Tank t2 = new Tank("Warrior",100,10,15,10);
		Hunter h1 = new Hunter("Archer",100,10,15,5);
		Hunter h2 = new Hunter("Shooter",100,10,15,5);
		Mage m1 = new Mage("Mage",100,10,15,5);
		Mage m2 = new Mage("Warlock",100,10,15,5);
		Brawler b1 = new Brawler("Brawler",100,10,15,5);
		Brawler b2 = new Brawler("Rouge",100,10,15,5);
		Boss1 Boss1 = new Boss1("Hell Raiser",200,12,17,1);
		Boss2 Boss2 = new Boss2("Final EXAM",200,12,17,1);
		
		Character[] C = {t1,t2,h1,h2,m1,m2,b1,b2,Boss1,Boss2};	
		
		
		  
	       
	    

	}

}